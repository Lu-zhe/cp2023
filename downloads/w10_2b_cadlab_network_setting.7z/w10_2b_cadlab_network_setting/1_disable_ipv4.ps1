# 關閉 IPv4 網路
Disable-NetAdapterBinding -Name "*" -ComponentID ms_tcpip
# 啟用 IPv6 網路
Enable-NetAdapterBinding -Name "*" -ComponentID ms_tcpip6
# 設置 IPv6 網路中的兩個 DNS 伺服器 (hinet)
$dnsServers = "2001:288:6004:17::3"
Set-DnsClientServerAddress -InterfaceAlias "*" -ServerAddresses $dnsServers